package hawrezproject;

public abstract class Hawrezproject extends Answer implements face {

    Hawrezproject(){
    
        super("hawa",2222);

        }
   
    public static void main(String[] args) {
        
        Name name=new Name();
        Question question=new Question();
        Answer answer=new Answer();
        
        name.setName("dler");
        name.setName2("kovan");
        question.setQuestion1("raparin saly chand anjam dra?");
        question.setQuestion2("slemani kay damazra?");
        answer.setAnswer1("1991");
        answer.setAnswer2("1867");
        
        System.out.println("  name: "+name.getName()+"   Question: "+question.getQuestion1()+"   Ansewr: "+answer.getAnswer1());
        System.out.println("  name2: "+name.getName2()+"   Question2: "+question.getQuestion2()+"   Ansewr2: "+answer.getAnswer2());
        
        System.out.println(answer.text);
        
        
       
}
    
    @Override
 public void overrideMethod(){
 
     System.out.println("this is overriding method");
 
 }

    @Override
    public void question_interface() {

        System.out.println("this is interface question");
    
    }

    @Override
    public void answer_interface() { 
        
        System.out.println("this is intrerface answer");
    }
    

 
 
    
    
}
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

class Name{
    
    
    private String name;
    private String name2;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }
   
}
 /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
class Question{
    
    String text="this is inheritance"; 
    
    private String question1;
    private String question2;

    public String getQuestion1() {
        return question1;
    }

    public void setQuestion1(String question1) {
        this.question1 = question1;
    }

    public String getQuestion2() {
        return question2;
    }

    public void setQuestion2(String question2) {
        this.question2 = question2;
    }


}
///////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////


class Answer extends Question{
  String name;
  int year;
  
  public Answer(){
  System.out.println("sdadasd");
  }
  public Answer(String name){
  this.name=name;
  }
  
   public Answer(String name,int year){
    this.name=name;
    this.year=year;
  }
    
    private String answer1;
    private String answer2;
    
    public String getAnswer1() {
        return answer1;
    }

    public void setAnswer1(String answer1) {
        this.answer1 = answer1;
    }

    public String getAnswer2() {
        return answer2;
    }

    public void setAnswer2(String answer2) {
        this.answer2 = answer2;
    }
    
    
     public void overrideMethod(){
 
     System.out.println("this is overriding method in child class");
 
 }   
}
         interface face{
        
             void question_interface();
             void answer_interface();
 
         }